onload = function()
{}

//Pick a jQuery library and plug it in and use it.